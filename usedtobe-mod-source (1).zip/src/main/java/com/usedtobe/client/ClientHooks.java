package com.usedtobe.client;

import com.mojang.blaze3d.shaders.FogShape;
import com.usedtobe.Config;
import com.usedtobe.UsedToBe;
import com.usedtobe.registry.ModDimensions;
import com.usedtobe.registry.ModEffects;
import com.usedtobe.registry.ModSounds;
import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.level.material.FogType;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.level.Level;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ClientPlayerNetworkEvent;
import net.minecraftforge.client.event.ViewportEvent;
import net.minecraftforge.client.event.sound.PlaySoundEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * Stage numbers: 0-4 = nostalgia decay, 5 = collapsing, 6 = brokenmemories, -1 = not in the mod's world.
 */
@Mod.EventBusSubscriber(modid = UsedToBe.MODID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class ClientHooks {
    // fog colour and distance per stage (0..6)
    private static final float[][] FOG_COLOR = {
            {0.62F, 0.78F, 1.00F}, // 0 peaceful blue
            {0.66F, 0.74F, 0.88F}, // 1
            {0.62F, 0.58F, 0.55F}, // 2 washed out
            {0.48F, 0.34F, 0.30F}, // 3 dusty
            {0.30F, 0.12F, 0.10F}, // 4 sick red-brown
            {0.16F, 0.03F, 0.04F}, // 5
            {0.22F, 0.02F, 0.04F}  // 6 brokenmemories
    };
    private static final float[] FOG_FAR = {56F, 48F, 40F, 32F, 26F, 20F, 22F};
    private static final int[] CHUNKS = {5, 4, 4, 3, 3, 2, 2};

    private static float[] curColor;
    private static float curFar = -1.0F;

    private static SoundInstance music;
    private static int musicDelay = 60;
    private static int musicGroup = -2;

    private ClientHooks() {}

    public static int stage() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null) {
            return -1;
        }
        ResourceKey<Level> dim = mc.level.dimension();
        if (dim.equals(ModDimensions.BROKEN)) {
            return 6;
        }
        if (dim.equals(ModDimensions.NOSTALGIA)) {
            MobEffectInstance rot = mc.player.getEffect(ModEffects.THE_ROT.get());
            return rot == null ? 0 : Math.min(rot.getAmplifier(), 5);
        }
        return -1;
    }

    // ---------------------------------------------------------------- fog = the low render distance

    @SubscribeEvent
    public static void onFog(ViewportEvent.RenderFog e) {
        int stage = stage();
        if (stage < 0 || e.getType() != FogType.NONE) {
            return;
        }
        float target = FOG_FAR[stage] * (float) Config.FOG_SCALE.get().doubleValue();
        curFar = curFar < 0.0F ? target : curFar + (target - curFar) * 0.02F;
        e.setNearPlaneDistance(0.0F);
        e.setFarPlaneDistance(curFar);
        e.setFogShape(FogShape.SPHERE);
        e.setCanceled(true); // tells Forge to use our values
    }

    @SubscribeEvent
    public static void onFogColor(ViewportEvent.ComputeFogColor e) {
        int stage = stage();
        if (stage < 0) {
            curColor = null;
            return;
        }
        float[] target = FOG_COLOR[stage];
        if (curColor == null) {
            curColor = target.clone();
        }
        for (int i = 0; i < 3; i++) {
            curColor[i] += (target[i] - curColor[i]) * 0.02F;
        }
        e.setRed(curColor[0]);
        e.setGreen(curColor[1]);
        e.setBlue(curColor[2]);
    }

    // ---------------------------------------------------------------- unease

    @SubscribeEvent
    public static void onCamera(ViewportEvent.ComputeCameraAngles e) {
        int stage = stage();
        if (stage < 3) {
            return;
        }
        float intensity = stage == 3 ? 0.25F : stage == 4 ? 0.7F : stage == 5 ? 1.4F : 0.12F;
        float t = Minecraft.getInstance().player.tickCount + (float) e.getPartialTick();
        e.setRoll(e.getRoll() + (float) Math.sin(t * 0.9D) * intensity * 0.6F);
        e.setPitch(e.getPitch() + (float) Math.sin(t * 1.7D) * intensity * 0.25F);
    }

    @SubscribeEvent
    public static void onFov(ViewportEvent.ComputeFov e) {
        if (stage() != 6) {
            return;
        }
        Minecraft mc = Minecraft.getInstance();
        double t = ((mc.level.getGameTime() % 24L) + e.getPartialTick()) / 24.0D;
        double lub = Math.exp(-Math.pow((t - 0.04D) / 0.07D, 2.0D));
        double dub = 0.7D * Math.exp(-Math.pow((t - 0.30D) / 0.06D, 2.0D));
        e.setFOV(e.getFOV() - Math.min(1.0D, lub + dub) * 3.0D); // the world breathes
    }

    // ---------------------------------------------------------------- sound

    @SubscribeEvent
    public static void onPlaySound(PlaySoundEvent e) {
        SoundInstance s = e.getSound();
        if (s == null || stage() < 0) {
            return;
        }
        // only our own soundtrack plays in here
        if (s.getSource() == SoundSource.MUSIC && !s.getLocation().getNamespace().equals(UsedToBe.MODID)) {
            e.setSound(null);
        }
    }

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END) {
            return;
        }
        Minecraft mc = Minecraft.getInstance();
        int stage = stage();

        if (stage < 0) {
            if (music != null) {
                mc.getSoundManager().stop(music);
                music = null;
            }
            musicGroup = -2;
            RenderDistanceClamp.release(mc);
            return;
        }
        RenderDistanceClamp.apply(mc, CHUNKS[stage]);
        if (mc.isPaused()) {
            return;
        }

        // soundtrack
        int group = stage <= 1 ? 0 : stage <= 3 ? 1 : stage <= 5 ? 2 : 3;
        if (group != musicGroup) {
            if (music != null) {
                mc.getSoundManager().stop(music);
                music = null;
            }
            musicGroup = group;
            musicDelay = 40;
        }
        if (music != null && !mc.getSoundManager().isActive(music)) {
            music = null;
            musicDelay = 300 + mc.level.random.nextInt(600); // silence between tracks
        }
        if (music == null && --musicDelay <= 0) {
            SoundEvent event = switch (group) {
                case 0 -> ModSounds.MUSIC_NOSTALGIA.get();
                case 1 -> ModSounds.MUSIC_DECAYING.get();
                case 2 -> ModSounds.MUSIC_ROTTING.get();
                default -> ModSounds.MUSIC_BROKEN.get();
            };
            music = SimpleSoundInstance.forMusic(event);
            mc.getSoundManager().play(music);
        }

        // heartbeat inside brokenmemories: lub-dub every 24 ticks
        if (stage == 6) {
            long m = mc.level.getGameTime() % 24L;
            SoundEvent beat = ModSounds.vanilla("entity.warden.heartbeat");
            if (beat != null && (m == 0L || m == 7L)) {
                mc.level.playLocalSound(mc.player.getX(), mc.player.getEyeY(), mc.player.getZ(), beat,
                        SoundSource.AMBIENT, m == 0L ? 0.9F : 0.6F, m == 0L ? 0.55F : 0.5F, false);
            }
        }
    }

    // ---------------------------------------------------------------- housekeeping

    @SubscribeEvent
    public static void onLogin(ClientPlayerNetworkEvent.LoggingIn e) {
        RenderDistanceClamp.recoverAfterCrash(Minecraft.getInstance());
    }

    @SubscribeEvent
    public static void onLogout(ClientPlayerNetworkEvent.LoggingOut e) {
        RenderDistanceClamp.release(Minecraft.getInstance());
        music = null;
        musicGroup = -2;
        curColor = null;
        curFar = -1.0F;
    }
}
