package com.usedtobe.registry;

import com.usedtobe.UsedToBe;
import com.usedtobe.block.MemoryHeartBlock;
import java.util.function.Supplier;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.RotatedPillarBlock;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModBlocks {
    public static final DeferredRegister<Block> BLOCKS = DeferredRegister.create(ForgeRegistries.BLOCKS, UsedToBe.MODID);

    private static BlockBehaviour.Properties props(MapColor color, float hardness, SoundType sound) {
        return BlockBehaviour.Properties.of().mapColor(color).strength(hardness).sound(sound);
    }

    private static <T extends Block> RegistryObject<T> reg(String name, Supplier<T> supplier) {
        RegistryObject<T> block = BLOCKS.register(name, supplier);
        ModItems.ITEMS.register(name, () -> new BlockItem(block.get(), new Item.Properties()));
        return block;
    }

    // ---- the world you remember (alpha-style) ----
    public static final RegistryObject<Block> OLD_GRASS = reg("old_grass", () -> new Block(props(MapColor.GRASS, 0.6F, SoundType.GRASS)));
    public static final RegistryObject<Block> OLD_DIRT = reg("old_dirt", () -> new Block(props(MapColor.DIRT, 0.5F, SoundType.GRAVEL)));
    public static final RegistryObject<Block> OLD_STONE = reg("old_stone", () -> new Block(props(MapColor.STONE, 1.5F, SoundType.STONE)));
    public static final RegistryObject<Block> OLD_COBBLE = reg("old_cobble", () -> new Block(props(MapColor.STONE, 2.0F, SoundType.STONE)));
    public static final RegistryObject<Block> OLD_PLANKS = reg("old_planks", () -> new Block(props(MapColor.WOOD, 2.0F, SoundType.WOOD)));
    public static final RegistryObject<RotatedPillarBlock> OLD_LOG = reg("old_log", () -> new RotatedPillarBlock(props(MapColor.WOOD, 2.0F, SoundType.WOOD)));
    public static final RegistryObject<Block> OLD_LEAVES = reg("old_leaves", () -> new Block(props(MapColor.PLANT, 0.2F, SoundType.GRASS)));

    // ---- what it is turning into ----
    public static final RegistryObject<Block> ROTTED_GRASS = reg("rotted_grass", () -> new Block(props(MapColor.COLOR_GRAY, 0.6F, SoundType.GRASS)));
    public static final RegistryObject<Block> CRACKED_EARTH = reg("cracked_earth", () -> new Block(props(MapColor.COLOR_BROWN, 0.6F, SoundType.GRAVEL)));

    // ---- brokenmemories ----
    public static final RegistryObject<Block> FLESH = reg("flesh", () -> new Block(props(MapColor.COLOR_RED, 1.0F, SoundType.WART_BLOCK)));
    public static final RegistryObject<Block> FLESH_FLOOR = reg("flesh_floor", () -> new Block(props(MapColor.CRIMSON_NYLIUM, 1.0F, SoundType.WART_BLOCK)));
    public static final RegistryObject<Block> FLESH_GLOW = reg("flesh_glow", () -> new Block(props(MapColor.COLOR_PINK, 1.0F, SoundType.WART_BLOCK).lightLevel(state -> 7)));

    public static final RegistryObject<Block> MEMORY_HEART = reg("memory_heart", () -> new MemoryHeartBlock(
            BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_RED).strength(-1.0F, 3600000.0F)
                    .sound(SoundType.WART_BLOCK).lightLevel(state -> 10).noOcclusion()));

    private ModBlocks() {}
}
