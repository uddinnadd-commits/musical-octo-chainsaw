package com.usedtobe.registry;

import com.usedtobe.UsedToBe;
import com.usedtobe.entity.EchoEntity;
import com.usedtobe.entity.ParasiteEntity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, UsedToBe.MODID);

    public static final RegistryObject<EntityType<ParasiteEntity>> PARASITE = ENTITIES.register("parasite",
            () -> EntityType.Builder.<ParasiteEntity>of(ParasiteEntity::new, MobCategory.MONSTER)
                    .sized(0.9F, 0.9F)
                    .clientTrackingRange(10)
                    .fireImmune()
                    .build(UsedToBe.MODID + ":parasite"));

    public static final RegistryObject<EntityType<EchoEntity>> ECHO = ENTITIES.register("echo",
            () -> EntityType.Builder.<EchoEntity>of(EchoEntity::new, MobCategory.MISC)
                    .sized(0.6F, 1.45F)
                    .clientTrackingRange(12)
                    .build(UsedToBe.MODID + ":echo"));

    private ModEntities() {}
}
