package com.usedtobe.registry;

import com.usedtobe.UsedToBe;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModSounds {
    public static final DeferredRegister<SoundEvent> SOUNDS = DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, UsedToBe.MODID);

    private static RegistryObject<SoundEvent> reg(String name) {
        return SOUNDS.register(name, () -> SoundEvent.createVariableRangeEvent(new ResourceLocation(UsedToBe.MODID, name)));
    }

    // All four reference vanilla's own C418 .ogg files through sounds.json (nothing is bundled).
    public static final RegistryObject<SoundEvent> MUSIC_NOSTALGIA = reg("music.nostalgia"); // untouched game music
    public static final RegistryObject<SoundEvent> MUSIC_DECAYING = reg("music.decaying");   // slowed down
    public static final RegistryObject<SoundEvent> MUSIC_ROTTING = reg("music.rotting");     // half speed
    public static final RegistryObject<SoundEvent> MUSIC_BROKEN = reg("music.broken");       // menu/creative at half speed

    /** Looks a vanilla sound up by path, e.g. "ambient.cave". Avoids Holder-vs-SoundEvent mapping differences. */
    public static SoundEvent vanilla(String path) {
        return ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("minecraft", path));
    }

    private ModSounds() {}
}
