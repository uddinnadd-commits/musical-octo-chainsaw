package com.usedtobe;

import net.minecraftforge.common.ForgeConfigSpec;

public final class Config {
    private static final ForgeConfigSpec.Builder B = new ForgeConfigSpec.Builder();

    public static final ForgeConfigSpec.BooleanValue AUTO_ENTER = B
            .comment("Drop every player into the nostalgia world the first time they join a world.")
            .define("autoEnterOnFirstJoin", true);

    public static final ForgeConfigSpec.IntValue COLLAPSE_MINUTES = B
            .comment("Fallback timer: if you never find enough notebooks, the world collapses on its own after this many minutes.")
            .defineInRange("collapseMinutes", 25, 1, 240);

    public static final ForgeConfigSpec.IntValue MEMORIES_REQUIRED = B
            .comment("How many of the 10-year-old's notebooks you must find in the nostalgia world to trigger the collapse (max 10).")
            .defineInRange("memoriesRequired", 5, 1, 10);

    public static final ForgeConfigSpec.IntValue HEARTS_REQUIRED = B
            .comment("How many hearts you must touch in brokenmemories to wake up.")
            .defineInRange("heartsRequired", 3, 1, 6);

    public static final ForgeConfigSpec.DoubleValue FOG_SCALE = B
            .comment("Multiplier for the fog wall that hides the world edge. 1.0 = default, lower = thicker.")
            .defineInRange("fogScale", 1.0D, 0.25D, 4.0D);

    public static final ForgeConfigSpec.BooleanValue CLAMP_RENDER_DISTANCE = B
            .comment("Really lower the client render distance while inside the mod's dimensions (restored on exit).",
                     "If false, only the fog wall is used.")
            .define("clampRenderDistance", true);

    public static final ForgeConfigSpec.IntValue PARASITE_CAP = B
            .comment("Max parasites haunting one player in brokenmemories.")
            .defineInRange("maxParasitesPerPlayer", 3, 1, 12);

    public static final ForgeConfigSpec SPEC = B.build();

    private Config() {}
}
