package com.usedtobe.world;

import com.usedtobe.UsedToBe;
import com.usedtobe.registry.ModBlocks;
import java.util.HashSet;
import java.util.Set;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.block.BedBlock;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.ChestBlock;
import net.minecraft.world.level.block.DoorBlock;
import net.minecraft.world.level.block.FenceBlock;
import net.minecraft.world.level.block.FenceGateBlock;
import net.minecraft.world.level.block.LadderBlock;
import net.minecraft.world.level.block.entity.RandomizableContainerBlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BedPart;
import net.minecraft.world.level.block.state.properties.DoubleBlockHalf;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.feature.FeaturePlaceContext;
import net.minecraft.world.level.levelgen.feature.configurations.NoneFeatureConfiguration;

/**
 * Trees plus the bases a ten-year-old builds. Most of them hold a Book and Quill the kid wrote.
 * Natural placement stays inside the chunk; the director also calls buildSite() to drop a specific base
 * wherever the player needs to go next.
 */
public class NostalgiaFeature extends Feature<NoneFeatureConfiguration> {
    public static final int GROUND = 64; // first air block above the grass layer

    /** Notebook ids the player can find out in the world (each is also a loot table chests/book_<id>). */
    public static final String[] NOTEBOOK_IDS = {
            "secret_base", "mega_house", "treasure", "nether", "trap", "pen", "graveyard", "pole", "castle"
    };

    private static final ResourceLocation GENERIC_LOOT = lootId("old_chest");

    public NostalgiaFeature() {
        super(NoneFeatureConfiguration.CODEC);
    }

    public static ResourceLocation lootId(String path) {
        return new ResourceLocation(UsedToBe.MODID, "chests/" + path);
    }

    @Override
    public boolean place(FeaturePlaceContext<NoneFeatureConfiguration> ctx) {
        WorldGenLevel level = ctx.level();
        RandomSource r = ctx.random();
        int x0 = ctx.origin().getX();
        int z0 = ctx.origin().getZ();

        if (r.nextInt(4) == 0) {
            switch (r.nextInt(15)) {
                case 0, 1 -> dirtHut(level, r, x0 + 1 + r.nextInt(9), z0 + 1 + r.nextInt(9), GENERIC_LOOT);
                case 2 -> cobbleHouse(level, r, x0 + 1 + r.nextInt(7), z0 + 1 + r.nextInt(7));
                case 3 -> woodHouse(level, r, x0 + 1 + r.nextInt(7), z0 + 1 + r.nextInt(8));
                case 4 -> pole(level, r, x0 + 2 + r.nextInt(12), z0 + 2 + r.nextInt(12));
                case 5 -> portalFrame(level, r, x0 + 1 + r.nextInt(9), z0 + 2 + r.nextInt(12));
                case 6 -> mineEntrance(level, r, x0 + 1 + r.nextInt(6), z0 + 2 + r.nextInt(12));
                case 7 -> secretBase(level, r, x0 + r.nextInt(9), z0 + r.nextInt(9));
                case 8 -> megaHouse(level, r, x0 + r.nextInt(5), z0 + r.nextInt(7));
                case 9 -> treasureX(level, r, x0 + r.nextInt(9), z0 + r.nextInt(9));
                case 10 -> trapHouse(level, r, x0 + r.nextInt(10), z0 + r.nextInt(10));
                case 11 -> zooPen(level, r, x0 + r.nextInt(7), z0 + r.nextInt(9));
                case 12 -> graveyard(level, r, x0 + r.nextInt(8), z0 + r.nextInt(11));
                case 13 -> castle(level, r, x0 + r.nextInt(3), z0 + r.nextInt(3));
                default -> tree(level, r, x0 + 2 + r.nextInt(12), z0 + 2 + r.nextInt(12));
            }
            return true;
        }
        if (r.nextInt(3) == 0) {
            int trees = 1 + r.nextInt(3);
            for (int i = 0; i < trees; i++) {
                tree(level, r, x0 + 2 + r.nextInt(12), z0 + 2 + r.nextInt(12));
            }
            return true;
        }
        return false;
    }

    // ---------------------------------------------------------------- sites the director can request

    /** {width (x), depth (z)} of the footprint for a notebook site. */
    public static int[] siteSize(String id) {
        return switch (id) {
            case "secret_base", "treasure" -> new int[] {7, 7};
            case "mega_house" -> new int[] {11, 9};
            case "nether" -> new int[] {6, 1};
            case "trap" -> new int[] {6, 6};
            case "pen" -> new int[] {9, 7};
            case "graveyard" -> new int[] {8, 5};
            case "pole" -> new int[] {3, 3};
            case "castle" -> new int[] {13, 13};
            default -> new int[] {5, 5};
        };
    }

    /** Builds the base for a notebook id with its min corner at (x, z). */
    public static void buildSite(LevelAccessor l, RandomSource r, String id, int x, int z) {
        switch (id) {
            case "secret_base" -> secretBase(l, r, x, z);
            case "mega_house" -> megaHouse(l, r, x, z);
            case "treasure" -> treasureX(l, r, x, z);
            case "nether" -> portalFrame(l, r, x, z);
            case "trap" -> trapHouse(l, r, x, z);
            case "pen" -> zooPen(l, r, x, z);
            case "graveyard" -> graveyard(l, r, x, z);
            case "pole" -> pole(l, r, x + 1, z + 1);
            case "castle" -> castle(l, r, x, z);
            default -> dirtHut(l, r, x, z, GENERIC_LOOT);
        }
    }

    // ---------------------------------------------------------------- the classics

    public static void dirtHut(LevelAccessor l, RandomSource r, int x, int z, ResourceLocation loot) {
        room(l, x, z, 5, 5, 2, ModBlocks.OLD_DIRT.get().defaultBlockState());
        box(l, x + 2, GROUND, z, x + 2, GROUND + 1, z, Blocks.AIR.defaultBlockState()); // doorway, no door
        set(l, x + 1, GROUND, z + 1, Blocks.TORCH.defaultBlockState());
        set(l, x + 3, GROUND, z + 3, Blocks.CRAFTING_TABLE.defaultBlockState());
        chestAt(l, r, x + 1, GROUND, z + 3, Direction.NORTH, loot);
    }

    public static void cobbleHouse(LevelAccessor l, RandomSource r, int x, int z) {
        room(l, x, z, 7, 7, 3, ModBlocks.OLD_COBBLE.get().defaultBlockState());
        BlockState air = Blocks.AIR.defaultBlockState();
        box(l, x + 3, GROUND, z, x + 3, GROUND + 1, z, air);
        set(l, x, GROUND + 1, z + 3, air);
        set(l, x + 6, GROUND + 1, z + 3, air);
        set(l, x + 1, GROUND, z + 1, Blocks.TORCH.defaultBlockState());
        set(l, x + 5, GROUND, z + 1, Blocks.TORCH.defaultBlockState());
        set(l, x + 5, GROUND, z + 5, Blocks.FURNACE.defaultBlockState());
        set(l, x + 4, GROUND, z + 5, Blocks.CRAFTING_TABLE.defaultBlockState());
        chestAt(l, r, x + 1, GROUND, z + 5, Direction.NORTH, GENERIC_LOOT);
    }

    public static void woodHouse(LevelAccessor l, RandomSource r, int x, int z) {
        BlockState planks = ModBlocks.OLD_PLANKS.get().defaultBlockState();
        BlockState log = ModBlocks.OLD_LOG.get().defaultBlockState();
        room(l, x, z, 7, 6, 3, planks);
        for (int cx : new int[] {x, x + 6}) {
            for (int cz : new int[] {z, z + 5}) {
                box(l, cx, GROUND, cz, cx, GROUND + 3, cz, log);
            }
        }
        BlockState glass = Blocks.GLASS.defaultBlockState();
        set(l, x, GROUND + 1, z + 2, glass);
        set(l, x + 6, GROUND + 1, z + 2, glass);
        set(l, x + 3, GROUND + 1, z + 5, glass);
        box(l, x + 3, GROUND, z, x + 3, GROUND + 1, z, Blocks.AIR.defaultBlockState());
        door(l, x + 3, z, Direction.NORTH);
        set(l, x + 1, GROUND, z + 1, Blocks.TORCH.defaultBlockState());
        set(l, x + 5, GROUND, z + 1, Blocks.TORCH.defaultBlockState());
        set(l, x + 5, GROUND, z + 4, Blocks.CRAFTING_TABLE.defaultBlockState());
        chestAt(l, r, x + 1, GROUND, z + 4, Direction.EAST, GENERIC_LOOT);
    }

    public static void mineEntrance(LevelAccessor l, RandomSource r, int x, int z) {
        BlockState planks = ModBlocks.OLD_PLANKS.get().defaultBlockState();
        BlockState air = Blocks.AIR.defaultBlockState();
        for (int i = 0; i < 9; i++) {
            int y = GROUND - 1 - i;
            box(l, x + i, y, z, x + i, y + 2, z, air);
        }
        box(l, x, GROUND, z - 1, x, GROUND + 1, z - 1, planks);
        box(l, x, GROUND, z + 1, x, GROUND + 1, z + 1, planks);
        box(l, x, GROUND + 2, z - 1, x, GROUND + 2, z + 1, planks);
        set(l, x + 1, GROUND - 1, z + 1, Blocks.TORCH.defaultBlockState());
    }

    public static void tree(LevelAccessor l, RandomSource r, int x, int z) {
        int h = 4 + r.nextInt(3);
        BlockState log = ModBlocks.OLD_LOG.get().defaultBlockState();
        BlockState leaves = ModBlocks.OLD_LEAVES.get().defaultBlockState();
        for (int dy = h - 3; dy <= h; dy++) {
            int rad = dy >= h - 1 ? 1 : 2;
            for (int dx = -rad; dx <= rad; dx++) {
                for (int dz = -rad; dz <= rad; dz++) {
                    boolean corner = Math.abs(dx) == rad && Math.abs(dz) == rad;
                    if (corner && (dy == h || r.nextBoolean())) {
                        continue;
                    }
                    BlockPos p = new BlockPos(x + dx, GROUND + dy, z + dz);
                    if (l.getBlockState(p).isAir()) {
                        l.setBlock(p, leaves, 2);
                    }
                }
            }
        }
        box(l, x, GROUND, z, x, GROUND + h - 1, z, log);
    }

    // ---------------------------------------------------------------- the ones with notebooks

    /** Nether portal frame one obsidian short, with a chest and the "how to go to the nether" notebook. */
    public static void portalFrame(LevelAccessor l, RandomSource r, int x, int z) {
        BlockState ob = Blocks.OBSIDIAN.defaultBlockState();
        box(l, x + 1, GROUND, z, x + 2, GROUND, z, ob);
        box(l, x + 1, GROUND + 4, z, x + 2, GROUND + 4, z, ob);
        box(l, x, GROUND + 1, z, x, GROUND + 3, z, ob);
        box(l, x + 3, GROUND + 1, z, x + 3, GROUND + 3, z, ob);
        set(l, x + 3, GROUND + 3, z, Blocks.AIR.defaultBlockState()); // ran out of obsidian
        chestAt(l, r, x + 5, GROUND, z, Direction.WEST, lootId("book_nether"));
    }

    /** Nerd pole with a ladder and a chest on top. */
    public static void pole(LevelAccessor l, RandomSource r, int x, int z) {
        int h = 8 + r.nextInt(10);
        BlockState dirt = ModBlocks.OLD_DIRT.get().defaultBlockState();
        BlockState planks = ModBlocks.OLD_PLANKS.get().defaultBlockState();
        box(l, x, GROUND, z, x, GROUND + h - 2, z, dirt);
        int py = GROUND + h - 1;
        box(l, x - 1, py, z - 1, x + 1, py, z, planks);
        set(l, x - 1, py, z + 1, planks);
        set(l, x + 1, py, z + 1, planks);
        BlockState ladder = Blocks.LADDER.defaultBlockState().setValue(LadderBlock.FACING, Direction.SOUTH);
        for (int y = GROUND; y <= GROUND + h; y++) {
            set(l, x, y, z + 1, ladder);
        }
        chestAt(l, r, x + 1, GROUND + h, z - 1, Direction.SOUTH, lootId("book_pole"));
        set(l, x - 1, GROUND + h, z - 1, Blocks.TORCH.defaultBlockState());
    }

    /** Underground room behind a ladder shaft. */
    public static void secretBase(LevelAccessor l, RandomSource r, int x, int z) {
        BlockState air = Blocks.AIR.defaultBlockState();
        BlockState planks = ModBlocks.OLD_PLANKS.get().defaultBlockState();
        box(l, x + 1, 56, z + 1, x + 5, 59, z + 5, air);                         // the room
        box(l, x + 3, 60, z + 1, x + 3, GROUND, z + 1, air);                     // shaft
        BlockState ladder = Blocks.LADDER.defaultBlockState().setValue(LadderBlock.FACING, Direction.SOUTH);
        for (int y = 56; y <= 63; y++) {
            set(l, x + 3, y, z + 1, ladder);
        }
        set(l, x + 2, GROUND, z + 1, planks);                                    // frame around the hatch
        set(l, x + 4, GROUND, z + 1, planks);
        set(l, x + 3, GROUND, z, planks);
        set(l, x + 1, 56, z + 1, Blocks.TORCH.defaultBlockState());
        set(l, x + 5, 56, z + 1, Blocks.TORCH.defaultBlockState());
        set(l, x + 5, 56, z + 4, Blocks.CRAFTING_TABLE.defaultBlockState());
        chestAt(l, r, x + 1, 56, z + 4, Direction.EAST, lootId("book_secret_base"));
    }

    /** Eleven by nine, every wall a different block, 4 of 40 rooms finished. */
    public static void megaHouse(LevelAccessor l, RandomSource r, int x, int z) {
        BlockState[] mix = {
                ModBlocks.OLD_PLANKS.get().defaultBlockState(), ModBlocks.OLD_COBBLE.get().defaultBlockState(),
                ModBlocks.OLD_DIRT.get().defaultBlockState(), Blocks.WHITE_WOOL.defaultBlockState(),
                Blocks.RED_WOOL.defaultBlockState(), Blocks.BLUE_WOOL.defaultBlockState(),
                Blocks.YELLOW_WOOL.defaultBlockState()
        };
        BlockState air = Blocks.AIR.defaultBlockState();
        int w = 11;
        int d = 9;
        int h = 3;
        box(l, x + 1, GROUND, z + 1, x + w - 2, GROUND + h - 1, z + d - 2, air);
        for (int dx = 0; dx < w; dx++) {
            for (int dz = 0; dz < d; dz++) {
                boolean edge = dx == 0 || dx == w - 1 || dz == 0 || dz == d - 1;
                for (int dy = 0; dy <= h; dy++) {
                    if (edge || dy == h) {
                        set(l, x + dx, GROUND + dy, z + dz, mix[r.nextInt(mix.length)]);
                    }
                }
            }
        }
        BlockState planks = ModBlocks.OLD_PLANKS.get().defaultBlockState();
        box(l, x + 5, GROUND, z + 1, x + 5, GROUND + h - 1, z + d - 2, planks);   // the wall between the two rooms
        box(l, x + 5, GROUND, z + 4, x + 5, GROUND + 1, z + 4, air);              // doorway between them
        BlockState glass = Blocks.GLASS.defaultBlockState();
        set(l, x, GROUND + 1, z + 3, glass);
        set(l, x, GROUND + 1, z + 6, glass);
        set(l, x + 10, GROUND + 1, z + 3, glass);
        set(l, x + 10, GROUND + 1, z + 6, glass);
        box(l, x + 2, GROUND, z, x + 2, GROUND + 1, z, air);
        door(l, x + 2, z, Direction.NORTH);
        // kitchen
        set(l, x + 1, GROUND, z + 1, Blocks.FURNACE.defaultBlockState());
        set(l, x + 2, GROUND, z + 1, Blocks.CRAFTING_TABLE.defaultBlockState());
        set(l, x + 4, GROUND, z + 7, Blocks.TORCH.defaultBlockState());
        // bedroom
        BlockPos foot = new BlockPos(x + 8, GROUND, z + 6);
        l.setBlock(foot, Blocks.RED_BED.defaultBlockState()
                .setValue(BedBlock.FACING, Direction.SOUTH).setValue(BedBlock.PART, BedPart.FOOT), 2);
        l.setBlock(foot.south(), Blocks.RED_BED.defaultBlockState()
                .setValue(BedBlock.FACING, Direction.SOUTH).setValue(BedBlock.PART, BedPart.HEAD), 2);
        set(l, x + 6, GROUND, z + 7, Blocks.TORCH.defaultBlockState());
        chestAt(l, r, x + 9, GROUND, z + 1, Direction.WEST, lootId("book_mega_house"));
    }

    /** A cobble X flush with the grass, a flag on top, the chest three blocks down. */
    public static void treasureX(LevelAccessor l, RandomSource r, int x, int z) {
        BlockState cobble = ModBlocks.OLD_COBBLE.get().defaultBlockState();
        for (int i = 0; i < 7; i++) {
            set(l, x + i, GROUND - 1, z + i, cobble);
            set(l, x + i, GROUND - 1, z + 6 - i, cobble);
        }
        chestAt(l, r, x + 3, GROUND - 3, z + 3, Direction.NORTH, lootId("book_treasure"));
        box(l, x + 3, GROUND, z + 3, x + 3, GROUND + 1, z + 3, Blocks.OAK_FENCE.defaultBlockState());
        set(l, x + 3, GROUND + 2, z + 3, Blocks.RED_WOOL.defaultBlockState());
    }

    /** A little plank house whose doorway opens straight onto a five-deep pit. */
    public static void trapHouse(LevelAccessor l, RandomSource r, int x, int z) {
        room(l, x, z, 6, 6, 3, ModBlocks.OLD_PLANKS.get().defaultBlockState());
        box(l, x + 2, GROUND, z, x + 2, GROUND + 1, z, Blocks.AIR.defaultBlockState());
        box(l, x + 1, 59, z + 1, x + 3, GROUND - 1, z + 2, Blocks.AIR.defaultBlockState()); // the pit
        set(l, x + 4, GROUND, z + 4, Blocks.TORCH.defaultBlockState());
        chestAt(l, r, x + 2, GROUND, z + 4, Direction.NORTH, lootId("book_trap"));
    }

    /** A fenced pen with a hay bale, and the hole Bacon fell in. */
    public static void zooPen(LevelAccessor l, RandomSource r, int x, int z) {
        int w = 9;
        int d = 7;
        Set<Long> perimeter = new HashSet<>();
        for (int dx = 0; dx < w; dx++) {
            for (int dz = 0; dz < d; dz++) {
                if (dx == 0 || dx == w - 1 || dz == 0 || dz == d - 1) {
                    perimeter.add(key(dx, dz));
                }
            }
        }
        BlockState fence = Blocks.OAK_FENCE.defaultBlockState();
        for (long k : perimeter) {
            int dx = (int) (k >> 32);
            int dz = (int) k;
            BlockState s;
            if (dz == 0 && dx == 4) {
                s = Blocks.OAK_FENCE_GATE.defaultBlockState().setValue(FenceGateBlock.FACING, Direction.SOUTH);
            } else {
                s = fence.setValue(FenceBlock.NORTH, perimeter.contains(key(dx, dz - 1)))
                        .setValue(FenceBlock.SOUTH, perimeter.contains(key(dx, dz + 1)))
                        .setValue(FenceBlock.EAST, perimeter.contains(key(dx + 1, dz)))
                        .setValue(FenceBlock.WEST, perimeter.contains(key(dx - 1, dz)));
            }
            set(l, x + dx, GROUND, z + dz, s);
        }
        set(l, x + 1, GROUND, z + 1, Blocks.HAY_BLOCK.defaultBlockState());
        box(l, x + 6, 59, z + 3, x + 6, GROUND - 1, z + 3, Blocks.AIR.defaultBlockState()); // the hole
        chestAt(l, r, x + 7, GROUND, z + 5, Direction.WEST, lootId("book_pen"));
    }

    public static void graveyard(LevelAccessor l, RandomSource r, int x, int z) {
        BlockState stone = ModBlocks.OLD_COBBLE.get().defaultBlockState();
        BlockState dirt = ModBlocks.OLD_DIRT.get().defaultBlockState();
        for (int i = 0; i < 4; i++) {
            int gx = x + 1 + i * 2;
            box(l, gx, GROUND, z + 1, gx, GROUND + 1, z + 1, stone);
            set(l, gx, GROUND, z + 2, dirt);
            if (r.nextBoolean()) {
                set(l, gx, GROUND + 1, z + 2, Blocks.POPPY.defaultBlockState());
            }
        }
        chestAt(l, r, x + 3, GROUND, z + 4, Direction.NORTH, lootId("book_graveyard"));
    }

    /** 13 wide, four towers, a keep, and a gold block for a throne. */
    public static void castle(LevelAccessor l, RandomSource r, int x, int z) {
        BlockState cobble = ModBlocks.OLD_COBBLE.get().defaultBlockState();
        BlockState planks = ModBlocks.OLD_PLANKS.get().defaultBlockState();
        BlockState air = Blocks.AIR.defaultBlockState();
        int w = 13;
        for (int dx = 0; dx < w; dx++) {
            for (int dz = 0; dz < w; dz++) {
                if (dx == 0 || dx == w - 1 || dz == 0 || dz == w - 1) {
                    box(l, x + dx, GROUND, z + dz, x + dx, GROUND + 3, z + dz, cobble);
                    if ((dx + dz) % 2 == 0) {
                        set(l, x + dx, GROUND + 4, z + dz, cobble);
                    }
                }
            }
        }
        for (int tx : new int[] {x, x + w - 3}) {
            for (int tz : new int[] {z, z + w - 3}) {
                box(l, tx, GROUND, tz, tx + 2, GROUND + 6, tz + 2, cobble);
                set(l, tx + 1, GROUND + 7, tz + 1, Blocks.RED_WOOL.defaultBlockState());
            }
        }
        box(l, x + 5, GROUND, z, x + 7, GROUND + 2, z, air);                       // gate
        room(l, x + 4, z + 5, 5, 5, 3, planks);                                     // keep
        box(l, x + 6, GROUND, z + 5, x + 6, GROUND + 1, z + 5, air);
        set(l, x + 7, GROUND, z + 8, Blocks.GOLD_BLOCK.defaultBlockState());        // throne
        set(l, x + 5, GROUND, z + 8, Blocks.TORCH.defaultBlockState());
        chestAt(l, r, x + 5, GROUND, z + 6, Direction.EAST, lootId("book_castle"));
    }

    // ---------------------------------------------------------------- helpers

    /** Flattens an area back to bare grass so a hand-placed base has room. */
    public static void clearArea(LevelAccessor l, int x1, int z1, int x2, int z2) {
        box(l, x1, GROUND, z1, x2, GROUND + 26, z2, Blocks.AIR.defaultBlockState());
        box(l, x1, GROUND - 1, z1, x2, GROUND - 1, z2, ModBlocks.OLD_GRASS.get().defaultBlockState());
    }

    public static void chestAt(LevelAccessor l, RandomSource r, int x, int y, int z, Direction facing, ResourceLocation loot) {
        BlockPos pos = new BlockPos(x, y, z);
        l.setBlock(pos, Blocks.CHEST.defaultBlockState().setValue(ChestBlock.FACING, facing), 2);
        RandomizableContainerBlockEntity.setLootTable(l, r, pos, loot);
    }

    private static long key(int dx, int dz) {
        return ((long) dx << 32) | (dz & 0xFFFFFFFFL);
    }

    private static void room(LevelAccessor l, int x, int z, int w, int d, int interior, BlockState wall) {
        box(l, x, GROUND, z, x + w - 1, GROUND + interior, z + d - 1, wall);
        box(l, x + 1, GROUND, z + 1, x + w - 2, GROUND + interior - 1, z + d - 2, Blocks.AIR.defaultBlockState());
    }

    private static void box(LevelAccessor l, int x1, int y1, int z1, int x2, int y2, int z2, BlockState s) {
        BlockPos.MutableBlockPos p = new BlockPos.MutableBlockPos();
        for (int x = x1; x <= x2; x++) {
            for (int y = y1; y <= y2; y++) {
                for (int z = z1; z <= z2; z++) {
                    l.setBlock(p.set(x, y, z), s, 2);
                }
            }
        }
    }

    private static void set(LevelAccessor l, int x, int y, int z, BlockState s) {
        l.setBlock(new BlockPos(x, y, z), s, 2);
    }

    private static void door(LevelAccessor l, int x, int z, Direction facing) {
        BlockState lower = Blocks.OAK_DOOR.defaultBlockState()
                .setValue(DoorBlock.FACING, facing)
                .setValue(DoorBlock.HALF, DoubleBlockHalf.LOWER);
        l.setBlock(new BlockPos(x, GROUND, z), lower, 2);
        l.setBlock(new BlockPos(x, GROUND + 1, z), lower.setValue(DoorBlock.HALF, DoubleBlockHalf.UPPER), 2);
    }
}
