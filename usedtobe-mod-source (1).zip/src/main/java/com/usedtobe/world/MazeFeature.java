package com.usedtobe.world;

import com.usedtobe.registry.ModBlocks;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.feature.FeaturePlaceContext;
import net.minecraft.world.level.levelgen.feature.configurations.NoneFeatureConfiguration;

/**
 * Infinite hash-driven maze. Every cell opens exactly one of its north/east walls (binary-tree
 * maze), so the whole thing is connected and can be generated chunk by chunk with no state.
 * Cell = 3x3 floor + 2 blocks of wall on the +x/+z sides.
 */
public class MazeFeature extends Feature<NoneFeatureConfiguration> {
    public static final int CELL = 5;
    public static final int FLOOR = 63;   // top block of the flat-world layers
    public static final int HEIGHT = 5;   // open air above the floor
    public static final int CEILING_MIN = FLOOR + HEIGHT + 1;
    public static final int CEILING_MAX = CEILING_MIN + 1;

    public MazeFeature() {
        super(NoneFeatureConfiguration.CODEC);
    }

    @Override
    public boolean place(FeaturePlaceContext<NoneFeatureConfiguration> ctx) {
        WorldGenLevel level = ctx.level();
        long seed = level.getSeed();
        BlockPos origin = ctx.origin();
        BlockState air = Blocks.AIR.defaultBlockState();
        BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();

        for (int lx = 0; lx < 16; lx++) {
            for (int lz = 0; lz < 16; lz++) {
                int x = origin.getX() + lx;
                int z = origin.getZ() + lz;
                boolean open = isOpen(seed, x, z);

                for (int y = FLOOR + 1; y < CEILING_MIN; y++) {
                    pos.set(x, y, z);
                    level.setBlock(pos, open ? air : wall(seed, x, y, z), 2);
                }
                for (int y = CEILING_MIN; y <= CEILING_MAX; y++) {
                    pos.set(x, y, z);
                    level.setBlock(pos, ceiling(seed, x, y, z), 2);
                }
                // a rare patch of grass someone remembers
                if (open && Math.floorMod(mix(seed, x, FLOOR, z), 53L) == 0L) {
                    pos.set(x, FLOOR, z);
                    level.setBlock(pos, ModBlocks.OLD_GRASS.get().defaultBlockState(), 2);
                }
            }
        }
        return true;
    }

    public static boolean isOpen(long seed, int x, int z) {
        int cx = Math.floorDiv(x, CELL);
        int cz = Math.floorDiv(z, CELL);
        int lx = Math.floorMod(x, CELL);
        int lz = Math.floorMod(z, CELL);
        boolean inX = lx < 3;
        boolean inZ = lz < 3;
        if (inX && inZ) {
            return true;
        }
        if (!inX && !inZ) {
            return false;
        }
        long h = mix(seed, cx, 7, cz);
        boolean east = (h & 1L) == 0L;
        boolean both = Math.floorMod(h >>> 8, 9L) == 0L; // occasional loop
        if (!inX) {
            return east || both; // east connector
        }
        return !east || both;    // north connector
    }

    private static BlockState wall(long seed, int x, int y, int z) {
        int r = (int) Math.floorMod(mix(seed, x, y, z), 100L);
        if (r < 3) { // something you used to build, fused into the meat
            return switch (r) {
                case 0 -> ModBlocks.OLD_PLANKS.get().defaultBlockState();
                case 1 -> ModBlocks.OLD_COBBLE.get().defaultBlockState();
                default -> ModBlocks.OLD_DIRT.get().defaultBlockState();
            };
        }
        if (r < 8 && y >= FLOOR + 2 && y <= FLOOR + 4) {
            return ModBlocks.FLESH_GLOW.get().defaultBlockState();
        }
        return ModBlocks.FLESH.get().defaultBlockState();
    }

    private static BlockState ceiling(long seed, int x, int y, int z) {
        int r = (int) Math.floorMod(mix(seed, x, y, z), 100L);
        return r < 3 ? ModBlocks.FLESH_GLOW.get().defaultBlockState() : ModBlocks.FLESH.get().defaultBlockState();
    }

    static long mix(long seed, int x, int y, int z) {
        long h = seed ^ (x * 0x9E3779B97F4A7C15L) ^ (y * 0xC2B2AE3D27D4EB4FL) ^ (z * 0x165667B19E3779F9L);
        h ^= h >>> 33;
        h *= 0xff51afd7ed558ccdL;
        h ^= h >>> 33;
        h *= 0xc4ceb9fe1a85ec53L;
        h ^= h >>> 33;
        return h;
    }
}
