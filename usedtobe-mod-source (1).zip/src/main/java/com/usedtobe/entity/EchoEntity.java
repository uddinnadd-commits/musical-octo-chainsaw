package com.usedtobe.entity;

import com.usedtobe.registry.ModSounds;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import net.minecraft.sounds.SoundSource;

/**
 * You, at ten. Stands far away and stares. Vanishes if you get close, look at it too long, or hit it.
 * Late in the decay it creeps toward you whenever you're not looking.
 */
public class EchoEntity extends PathfinderMob {
    private boolean creeping;
    private int watchedTicks;
    private int lonelyTicks;

    public EchoEntity(EntityType<? extends EchoEntity> type, Level level) {
        super(type, level);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 10.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.25D);
    }

    public void setCreeping(boolean creeping) {
        this.creeping = creeping;
    }

    @Override
    public void tick() {
        super.tick();
        if (!(this.level() instanceof ServerLevel server)) {
            return;
        }

        Player p = server.getNearestPlayer(this, 90.0D);
        if (p == null || p.isSpectator()) {
            if (++this.lonelyTicks > 600) {
                this.discard();
            }
            return;
        }
        this.lonelyTicks = 0;

        double dx = p.getX() - this.getX();
        double dz = p.getZ() - this.getZ();
        double dist = Math.sqrt(dx * dx + dz * dz);

        // always facing you
        float yaw = (float) (Mth.atan2(-dx, dz) * (180.0D / Math.PI));
        this.setYRot(yaw);
        this.yBodyRot = yaw;
        this.yHeadRot = yaw;

        boolean watched = this.isWatchedBy(p);
        this.watchedTicks = watched ? this.watchedTicks + 1 : Math.max(0, this.watchedTicks - 1);

        if (dist < 7.0D || this.watchedTicks > 50) {
            this.vanish(server);
            return;
        }

        Vec3 motion = this.getDeltaMovement();
        if (this.creeping && !watched && dist > 1.0D) {
            this.setDeltaMovement(dx / dist * 0.05D, motion.y, dz / dist * 0.05D);
        } else {
            this.setDeltaMovement(0.0D, motion.y, 0.0D);
        }
    }

    private boolean isWatchedBy(Player p) {
        Vec3 look = p.getViewVector(1.0F);
        Vec3 to = this.getBoundingBox().getCenter().subtract(p.getEyePosition()).normalize();
        return look.dot(to) > 0.93D && p.hasLineOfSight(this);
    }

    private void vanish(ServerLevel server) {
        server.sendParticles(ParticleTypes.SOUL, this.getX(), this.getY() + 0.8D, this.getZ(), 14, 0.3D, 0.6D, 0.3D, 0.02D);
        server.playSound(null, this.getX(), this.getY(), this.getZ(),
                ModSounds.vanilla("block.sculk_sensor.clicking_stop"), SoundSource.AMBIENT, 0.8F, 0.6F);
        this.discard();
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (this.level() instanceof ServerLevel server) {
            this.vanish(server);
        }
        return false;
    }

    @Override
    public boolean isPushable() {
        return false;
    }
}
