import json, math, os, random, struct, zlib

ROOT = '/home/claude/usedtobe/src/main'
A = f'{ROOT}/resources/assets/usedtobe'
D = f'{ROOT}/resources/data/usedtobe'

def mk(path):
    os.makedirs(os.path.dirname(path), exist_ok=True)

def wjson(path, obj):
    mk(path)
    with open(path, 'w') as f:
        json.dump(obj, f, indent=2)

def clamp(v):
    return max(0, min(255, int(round(v))))

def save_png(path, rows):
    mk(path)
    h, w = len(rows), len(rows[0])
    raw = bytearray()
    for row in rows:
        raw.append(0)
        for c in row:
            a = c[3] if len(c) > 3 else 255
            raw += bytes((clamp(c[0]), clamp(c[1]), clamp(c[2]), a))
    def chunk(t, d):
        body = t + d
        return struct.pack('>I', len(d)) + body + struct.pack('>I', zlib.crc32(body) & 0xffffffff)
    png = (b'\x89PNG\r\n\x1a\n'
           + chunk(b'IHDR', struct.pack('>IIBBBBB', w, h, 8, 6, 0, 0, 0))
           + chunk(b'IDAT', zlib.compress(bytes(raw), 9))
           + chunk(b'IEND', b''))
    with open(path, 'wb') as f:
        f.write(png)

def noisy(base, var, rng, w=16, h=16):
    rows = []
    for y in range(h):
        row = []
        for x in range(w):
            n = rng.randint(-var, var)
            row.append((base[0] + n, base[1] + n, base[2] + n))
        rows.append(row)
    return rows

def speckle(rows, color, chance, rng):
    for row in rows:
        for x in range(len(row)):
            if rng.random() < chance:
                row[x] = color
    return rows

# ---------------------------------------------------------------- alpha-style blocks
def tex_dirt(rng):
    return speckle(noisy((134, 96, 67), 20, rng), (98, 66, 42), 0.05, rng)

def tex_stone(rng):
    return speckle(noisy((126, 126, 126), 14, rng), (88, 88, 88), 0.06, rng)

def tex_grass_top(rng):
    return speckle(noisy((98, 158, 52), 24, rng), (60, 110, 30), 0.05, rng)

def tex_grass_side(rng, green=(98, 158, 52), dirt=None):
    rows = dirt or tex_dirt(rng)
    for x in range(16):
        depth = 3 + (1 if rng.random() < 0.5 else 0) + (1 if rng.random() < 0.2 else 0)
        for y in range(depth):
            n = rng.randint(-22, 22)
            rows[y][x] = (green[0] + n, green[1] + n, green[2] + n)
    return rows

def tex_cobble(rng):
    pts = [(rng.uniform(0, 16), rng.uniform(0, 16)) for _ in range(9)]
    shade = [rng.randint(100, 150) for _ in pts]
    rows = []
    for y in range(16):
        row = []
        for x in range(16):
            ds = []
            for i, (px, py) in enumerate(pts):
                d = min(math.hypot(x - px + dx, y - py + dy) for dx in (-16, 0, 16) for dy in (-16, 0, 16))
                ds.append((d, i))
            ds.sort()
            edge = (ds[1][0] - ds[0][0]) < 1.1
            v = shade[ds[0][1]] + rng.randint(-9, 9)
            if edge:
                v -= 45
            row.append((v, v, v))
        rows.append(row)
    return rows

def tex_planks(rng):
    rows = []
    seam = [rng.randint(2, 13) for _ in range(4)]
    for y in range(16):
        row = []
        for x in range(16):
            n = rng.randint(-8, 8)
            c = (160 + n, 130 + n, 80 + n)
            if y % 4 == 3:
                c = (c[0] - 38, c[1] - 34, c[2] - 28)
            elif x == seam[y // 4]:
                c = (c[0] - 25, c[1] - 22, c[2] - 18)
            row.append(c)
        rows.append(row)
    return rows

def tex_log_side(rng):
    col = [rng.randint(-14, 14) for _ in range(16)]
    rows = []
    for y in range(16):
        row = []
        for x in range(16):
            n = col[x] + rng.randint(-5, 5)
            c = (104 + n, 82 + n, 50 + n)
            if rng.random() < 0.05:
                c = (60, 46, 28)
            row.append(c)
        rows.append(row)
    return rows

def tex_log_top(rng):
    rows = []
    for y in range(16):
        row = []
        for x in range(16):
            dist = max(abs(x - 7.5), abs(y - 7.5))
            n = rng.randint(-5, 5)
            if dist >= 7:
                c = (104 + n, 82 + n, 50 + n)
            elif int(dist) % 2 == 0:
                c = (156 + n, 126 + n, 78 + n)
            else:
                c = (174 + n, 142 + n, 90 + n)
            row.append(c)
        rows.append(row)
    return rows

def tex_leaves(rng):
    return speckle(noisy((42, 106, 28), 22, rng), (18, 62, 14), 0.16, rng)

def tex_rotted_top(rng):
    return speckle(noisy((96, 92, 62), 16, rng), (38, 34, 26), 0.12, rng)

def tex_rotted_side(rng):
    rows = tex_dirt(rng)
    for x in range(16):
        depth = 3 + rng.randint(0, 2)
        for y in range(depth):
            n = rng.randint(-16, 16)
            rows[y][x] = (96 + n, 92 + n, 62 + n)
    return rows

def tex_cracked(rng):
    rows = noisy((94, 74, 58), 12, rng)
    for _ in range(3):
        x, y, ang = rng.uniform(0, 16), rng.uniform(0, 16), rng.uniform(0, 6.28)
        for _ in range(20):
            rows[int(y) % 16][int(x) % 16] = (26, 20, 16)
            ang += rng.uniform(-0.8, 0.8)
            x += math.cos(ang)
            y += math.sin(ang)
    return rows

# ---------------------------------------------------------------- flesh (animated)
def flesh_strip(seed, base, vein, pale, bright, frames=12):
    rng = random.Random(seed)
    T = [[None] * 16 for _ in range(16)]
    for y in range(16):
        for x in range(16):
            n = rng.randint(-14, 14)
            T[y][x] = (base[0] + n, base[1] + n // 2, base[2] + n // 2)
    vm = [[0] * 16 for _ in range(16)]
    for _ in range(4):
        x, y, ang = rng.uniform(0, 16), rng.uniform(0, 16), rng.uniform(0, 6.28)
        for _ in range(24):
            vm[int(y) % 16][int(x) % 16] = 1
            ang += rng.uniform(-0.7, 0.7)
            x += math.cos(ang)
            y += math.sin(ang)
    pm = [[1 if rng.random() < 0.05 else 0 for _ in range(16)] for _ in range(16)]
    strip = []
    for f in range(frames):
        t = f / frames
        beat = min(1.0, math.exp(-((t - 0.04) / 0.07) ** 2) + 0.7 * math.exp(-((t - 0.30) / 0.06) ** 2))
        for y in range(16):
            row = []
            for x in range(16):
                sx = (x + int(round(math.sin(y * 0.9 + x * 0.3) * beat * 1.2))) % 16
                sy = (y + int(round(math.cos(x * 0.8) * beat * 1.0))) % 16
                if vm[sy][sx]:
                    c = (vein[0] + beat * 45, vein[1] + beat * 10, vein[2] + beat * 20)
                elif pm[sy][sx]:
                    c = pale
                else:
                    c = T[sy][sx]
                k = bright * (0.78 + 0.34 * beat)
                row.append((c[0] * k, c[1] * k, c[2] * k))
            strip.append(row)
    return strip

def parasite_tex():
    rng = random.Random(77)
    w, h = 64, 32
    rows = [[None] * w for _ in range(h)]
    for y in range(h):
        for x in range(w):
            n = rng.randint(-16, 16)
            rows[y][x] = (128 + n, 34 + n // 2, 44 + n // 2)
    for _ in range(14):
        x, y, ang = rng.uniform(0, w), rng.uniform(0, h), rng.uniform(0, 6.28)
        for _ in range(30):
            rows[int(y) % h][int(x) % w] = (84, 14, 46)
            ang += rng.uniform(-0.7, 0.7)
            x += math.cos(ang)
            y += math.sin(ang)
    for _ in range(40):
        rows[rng.randrange(h)][rng.randrange(w)] = (214, 176, 132)
    for _ in range(9):  # eyes
        ex, ey = rng.randrange(1, w - 2), rng.randrange(1, h - 2)
        for dx in (-1, 0, 1):
            for dy in (-1, 0, 1):
                rows[ey + dy][ex + dx] = (236, 226, 200)
        rows[ey][ex] = (10, 0, 0)
    return rows

# ---------------------------------------------------------------- write textures
rng = random.Random(1)
TB = f'{A}/textures/block'
save_png(f'{TB}/old_dirt.png', tex_dirt(rng))
save_png(f'{TB}/old_stone.png', tex_stone(rng))
save_png(f'{TB}/old_grass_top.png', tex_grass_top(rng))
save_png(f'{TB}/old_grass_side.png', tex_grass_side(rng))
save_png(f'{TB}/old_cobble.png', tex_cobble(rng))
save_png(f'{TB}/old_planks.png', tex_planks(rng))
save_png(f'{TB}/old_log_side.png', tex_log_side(rng))
save_png(f'{TB}/old_log_top.png', tex_log_top(rng))
save_png(f'{TB}/old_leaves.png', tex_leaves(rng))
save_png(f'{TB}/rotted_grass_top.png', tex_rotted_top(rng))
save_png(f'{TB}/rotted_grass_side.png', tex_rotted_side(rng))
save_png(f'{TB}/cracked_earth.png', tex_cracked(rng))

for name, seed, base, vein, pale, bright in [
    ('flesh', 11, (150, 40, 52), (96, 14, 52), (214, 150, 140), 1.0),
    ('flesh_floor', 12, (118, 30, 40), (72, 10, 40), (190, 130, 120), 0.9),
    ('flesh_glow', 13, (206, 96, 92), (150, 30, 70), (250, 200, 170), 1.15),
]:
    save_png(f'{TB}/{name}.png', flesh_strip(seed, base, vein, pale, bright))
    wjson(f'{TB}/{name}.png.mcmeta', {'animation': {'frametime': 2, 'interpolate': True}})

save_png(f'{A}/textures/entity/parasite.png', parasite_tex())

# ---------------------------------------------------------------- models / blockstates
ALL = ['old_dirt', 'old_stone', 'old_cobble', 'old_planks', 'old_leaves', 'cracked_earth', 'flesh', 'flesh_floor', 'flesh_glow']
for n in ALL:
    wjson(f'{A}/models/block/{n}.json', {'parent': 'minecraft:block/cube_all', 'textures': {'all': f'usedtobe:block/{n}'}})
    wjson(f'{A}/blockstates/{n}.json', {'variants': {'': {'model': f'usedtobe:block/{n}'}}})

for n, top, side in [('old_grass', 'old_grass_top', 'old_grass_side'), ('rotted_grass', 'rotted_grass_top', 'rotted_grass_side')]:
    wjson(f'{A}/models/block/{n}.json', {
        'parent': 'minecraft:block/cube_bottom_top',
        'textures': {'top': f'usedtobe:block/{top}', 'bottom': 'usedtobe:block/old_dirt', 'side': f'usedtobe:block/{side}'}})
    wjson(f'{A}/blockstates/{n}.json', {'variants': {'': {'model': f'usedtobe:block/{n}'}}})

wjson(f'{A}/models/block/old_log.json', {
    'parent': 'minecraft:block/cube_column',
    'textures': {'end': 'usedtobe:block/old_log_top', 'side': 'usedtobe:block/old_log_side'}})
wjson(f'{A}/blockstates/old_log.json', {'variants': {
    'axis=y': {'model': 'usedtobe:block/old_log'},
    'axis=z': {'model': 'usedtobe:block/old_log', 'x': 90},
    'axis=x': {'model': 'usedtobe:block/old_log', 'x': 90, 'y': 90}}})

BLOCKS = ALL + ['old_grass', 'rotted_grass', 'old_log']
for n in BLOCKS:
    wjson(f'{A}/models/item/{n}.json', {'parent': f'usedtobe:block/{n}'})
wjson(f'{A}/models/item/parasite_spawn_egg.json', {'parent': 'minecraft:item/template_spawn_egg'})

# ---------------------------------------------------------------- lang + sounds
wjson(f'{A}/lang/en_us.json', {
    'block.usedtobe.old_grass': 'Old Grass',
    'block.usedtobe.old_dirt': 'Old Dirt',
    'block.usedtobe.old_stone': 'Old Stone',
    'block.usedtobe.old_cobble': 'Old Cobblestone',
    'block.usedtobe.old_planks': 'Old Planks',
    'block.usedtobe.old_log': 'Old Log',
    'block.usedtobe.old_leaves': 'Old Leaves',
    'block.usedtobe.rotted_grass': 'Rotted Grass',
    'block.usedtobe.cracked_earth': 'Cracked Earth',
    'block.usedtobe.flesh': 'Flesh',
    'block.usedtobe.flesh_floor': 'Flesh Floor',
    'block.usedtobe.flesh_glow': 'Glowing Flesh',
    'item.usedtobe.parasite_spawn_egg': 'Parasite Spawn Egg',
    'entity.usedtobe.parasite': 'Parasite',
    'effect.usedtobe.the_rot': 'The Rot',
})

def s(name, pitch=None):
    o = {'name': name, 'stream': True}
    if pitch:
        o['pitch'] = pitch
    return o

calm = [f'minecraft:music/game/calm{i}' for i in (1, 2, 3)]
piano = [f'minecraft:music/game/piano{i}' for i in (1, 2, 3)]
hal = [f'minecraft:music/game/hal{i}' for i in (1, 2, 3, 4)]
nuance = [f'minecraft:music/game/nuance{i}' for i in (1, 2)]
menu = [f'minecraft:music/menu/menu{i}' for i in (1, 2, 3, 4)]
creative = [f'minecraft:music/game/creative/creative{i}' for i in range(1, 7)]
wjson(f'{A}/sounds.json', {
    'music.nostalgia': {'sounds': [s(n) for n in calm + piano]},
    'music.decaying': {'sounds': [s(n, 0.75) for n in calm + piano + hal]},
    'music.rotting': {'sounds': [s(n, 0.55) for n in hal + nuance + calm]},
    'music.broken': {'sounds': [s(n, 0.5) for n in menu + creative]},
})

# ---------------------------------------------------------------- data pack
def dimtype(sky, ceiling, ambient, effects):
    return {
        'ultrawarm': False, 'natural': sky, 'coordinate_scale': 1.0, 'has_skylight': sky, 'has_ceiling': ceiling,
        'ambient_light': ambient, 'piglin_safe': False, 'bed_works': False, 'respawn_anchor_works': False,
        'has_raids': False, 'logical_height': 256, 'min_y': 0, 'height': 256,
        'infiniburn': '#minecraft:infiniburn_overworld', 'effects': effects,
        'monster_spawn_light_level': 0, 'monster_spawn_block_light_limit': 0}

wjson(f'{D}/dimension_type/nostalgia.json', dimtype(True, False, 0.0, 'minecraft:overworld'))
wjson(f'{D}/dimension_type/brokenmemories.json', dimtype(False, True, 0.12, 'minecraft:the_nether'))

def flat(biome, layers):
    return {'type': f'usedtobe:{biome[1]}', 'generator': {'type': 'minecraft:flat', 'settings': {
        'biome': f'usedtobe:{biome[0]}', 'lakes': False, 'features': True, 'structure_overrides': [],
        'layers': layers}}}

wjson(f'{D}/dimension/nostalgia.json', flat(('remembered', 'nostalgia'), [
    {'block': 'minecraft:bedrock', 'height': 1},
    {'block': 'usedtobe:old_stone', 'height': 59},
    {'block': 'usedtobe:old_dirt', 'height': 3},
    {'block': 'usedtobe:old_grass', 'height': 1}]))
wjson(f'{D}/dimension/brokenmemories.json', flat(('hollow', 'brokenmemories'), [
    {'block': 'minecraft:bedrock', 'height': 1},
    {'block': 'usedtobe:flesh_floor', 'height': 63}]))

def spawners(creature):
    return {'monster': [], 'creature': creature, 'ambient': [], 'axolotls': [], 'underground_water_creature': [],
            'water_creature': [], 'water_ambient': [], 'misc': []}

def feats(step, fid):
    f = [[] for _ in range(11)]
    f[step] = [fid]
    return f

wjson(f'{D}/worldgen/biome/remembered.json', {
    'temperature': 0.8, 'downfall': 0.4, 'has_precipitation': False,
    'creature_spawn_probability': 0.1,
    'effects': {'sky_color': 7907327, 'fog_color': 12638463, 'water_color': 4159204, 'water_fog_color': 329011},
    'carvers': {},
    'features': feats(4, 'usedtobe:old_bases'),
    'spawners': spawners([
        {'type': 'minecraft:sheep', 'weight': 12, 'minCount': 2, 'maxCount': 4},
        {'type': 'minecraft:pig', 'weight': 10, 'minCount': 2, 'maxCount': 4},
        {'type': 'minecraft:chicken', 'weight': 10, 'minCount': 2, 'maxCount': 4},
        {'type': 'minecraft:cow', 'weight': 8, 'minCount': 2, 'maxCount': 4}]),
    'spawn_costs': {}})

wjson(f'{D}/worldgen/biome/hollow.json', {
    'temperature': 0.8, 'downfall': 0.4, 'has_precipitation': False,
    'creature_spawn_probability': 0.0,
    'effects': {
        'sky_color': 3802376, 'fog_color': 3802376, 'water_color': 4159204, 'water_fog_color': 329011,
        'ambient_sound': 'minecraft:ambient.crimson_forest.loop',
        'additions_sound': {'sound': 'minecraft:ambient.crimson_forest.additions', 'tick_chance': 0.0111},
        'mood_sound': {'sound': 'minecraft:ambient.crimson_forest.mood', 'tick_delay': 6000, 'block_search_extent': 8, 'offset': 2.0},
        'particle': {'probability': 0.025, 'options': {'type': 'minecraft:crimson_spore'}}},
    'carvers': {},
    'features': feats(4, 'usedtobe:memory_maze'),
    'spawners': spawners([]),
    'spawn_costs': {}})

for cfg, placed, ftype in [('old_bases', 'old_bases', 'usedtobe:nostalgia_world'),
                           ('memory_maze', 'memory_maze', 'usedtobe:memory_maze')]:
    wjson(f'{D}/worldgen/configured_feature/{cfg}.json', {'type': ftype, 'config': {}})
    wjson(f'{D}/worldgen/placed_feature/{placed}.json', {'feature': f'usedtobe:{cfg}', 'placement': []})

def item(name, weight, lo=None, hi=None):
    e = {'type': 'minecraft:item', 'name': name, 'weight': weight}
    if lo:
        e['functions'] = [{'function': 'minecraft:set_count', 'count': {'type': 'minecraft:uniform', 'min': lo, 'max': hi}}]
    return e

wjson(f'{D}/loot_tables/chests/old_chest.json', {'type': 'minecraft:chest', 'pools': [{
    'rolls': {'type': 'minecraft:uniform', 'min': 3, 'max': 6},
    'entries': [
        item('minecraft:bread', 6, 1, 4), item('minecraft:apple', 5, 1, 3), item('minecraft:torch', 8, 4, 16),
        item('minecraft:coal', 6, 2, 8), item('minecraft:cobblestone', 7, 8, 32), item('minecraft:oak_planks', 6, 8, 24),
        item('minecraft:wooden_sword', 3), item('minecraft:stone_pickaxe', 3), item('minecraft:iron_ingot', 3, 1, 4),
        item('minecraft:cooked_porkchop', 4, 1, 3), item('minecraft:diamond', 1)]}]})

for n in BLOCKS:
    wjson(f'{D}/loot_tables/blocks/{n}.json', {'type': 'minecraft:block', 'pools': [{
        'rolls': 1.0, 'bonus_rolls': 0.0,
        'entries': [{'type': 'minecraft:item', 'name': f'usedtobe:{n}'}],
        'conditions': [{'condition': 'minecraft:survives_explosion'}]}]})

def tag(path, values):
    wjson(path, {'replace': False, 'values': values})

MC = f'{ROOT}/resources/data/minecraft/tags/blocks'
tag(f'{MC}/mineable/pickaxe.json', ['usedtobe:old_stone', 'usedtobe:old_cobble'])
tag(f'{MC}/mineable/axe.json', ['usedtobe:old_planks', 'usedtobe:old_log'])
tag(f'{MC}/mineable/shovel.json', ['usedtobe:old_grass', 'usedtobe:old_dirt', 'usedtobe:rotted_grass', 'usedtobe:cracked_earth'])
tag(f'{MC}/mineable/hoe.json', ['usedtobe:flesh', 'usedtobe:flesh_floor', 'usedtobe:flesh_glow', 'usedtobe:old_leaves'])
tag(f'{MC}/animals_spawnable_on.json', ['usedtobe:old_grass'])

print('assets ok')


# =====================================================================================
# v2: custom model textures (UV-aware), memory heart, notebooks
# =====================================================================================
def blank(w, h):
    return [[(0, 0, 0, 0) for _ in range(w)] for _ in range(h)]

def paint_box(img, u, v, w, h, d, fn):
    """Paints one box using Minecraft's standard cube unwrap, matching texOffs(u, v).addBox(.., w, h, d)."""
    faces = {
        'east':   (u,             v + d, d, h),
        'front':  (u + d,         v + d, w, h),
        'west':   (u + d + w,     v + d, d, h),
        'back':   (u + 2 * d + w, v + d, w, h),
        'top':    (u + d,         v,     w, d),
        'bottom': (u + d + w,     v,     w, d),
    }
    for name, (fx, fy, fw, fh) in faces.items():
        for y in range(fh):
            for x in range(fw):
                img[fy + y][fx + x] = fn(name, x, y, fw, fh)

# ---------------------------------------------------------------- parasite (64x64)
def flesh_fn(seed, base=(130, 34, 44), ring=False):
    rng = random.Random(seed)
    def fn(face, x, y, fw, fh):
        n = rng.randint(-16, 16)
        c = [base[0] + n, base[1] + n // 2, base[2] + n // 2]
        r = rng.random()
        if r < 0.06:
            c = [84, 14, 46]
        elif r < 0.09:
            c = [214, 176, 132]
        if ring and y % 4 == 3:
            c = [c[0] * 0.7, c[1] * 0.7, c[2] * 0.7]
        return (c[0], c[1], c[2], 255)
    return fn

def head_fn():
    base = flesh_fn(1)
    def fn(face, x, y, fw, fh):
        if face == 'front':                       # 8 x 7
            if y in (1, 2) and (x in (1, 2) or x in (5, 6)):
                return (10, 0, 0, 255) if (y == 2 and x in (1, 6)) else (236, 226, 200, 255)
            if y in (4, 5):                       # the mouth
                if y == 5 and x % 2 == 0:
                    return (240, 235, 215, 255)   # teeth
                return (40, 4, 10, 255)
        return base(face, x, y, fw, fh)
    return fn

def jaw_fn(seed):
    rng = random.Random(seed)
    def fn(face, x, y, fw, fh):
        n = rng.randint(-14, 14)
        return (206 + n, 192 + n, 160 + n, 255)
    return fn

def sac_fn():
    rng = random.Random(9)
    def fn(face, x, y, fw, fh):
        n = rng.randint(-12, 12)
        c = (232 + n, 176 + n, 120 + n)
        if rng.random() < 0.1:
            c = (255, 232, 190)
        return (c[0], c[1], c[2], 255)
    return fn

def leg_fn(face, x, y, fw, fh):
    return (72, 10, 32, 255)

para = blank(64, 64)
paint_box(para, 0, 0, 8, 7, 7, head_fn())
paint_box(para, 32, 0, 2, 2, 5, jaw_fn(3))
paint_box(para, 32, 8, 2, 2, 5, jaw_fn(4))
paint_box(para, 0, 15, 10, 9, 8, flesh_fn(2, ring=True))
paint_box(para, 0, 32, 10, 9, 8, flesh_fn(5, ring=True))
paint_box(para, 0, 49, 8, 7, 7, flesh_fn(6, ring=True))
paint_box(para, 36, 16, 6, 5, 6, flesh_fn(7, ring=True))
paint_box(para, 36, 28, 4, 3, 5, flesh_fn(8))
paint_box(para, 36, 38, 6, 3, 6, sac_fn())
paint_box(para, 36, 48, 1, 5, 1, leg_fn)
save_png(f'{A}/textures/entity/parasite.png', para)

# ---------------------------------------------------------------- echo: you at ten (64x64, see-through)
SKIN, HAIR, SHIRT, PANTS, SHOE = (224, 172, 132), (92, 62, 38), (74, 138, 78), (74, 84, 120), (60, 42, 30)
ALPHA = 215
erng = random.Random(21)

def tint(c, v=7):
    n = erng.randint(-v, v)
    return (c[0] + n, c[1] + n, c[2] + n, ALPHA)

def echo_head(face, x, y, fw, fh):
    if face in ('top', 'back'):
        return tint(HAIR)
    if face in ('east', 'west'):
        return tint(HAIR if y < 4 else SKIN)
    if face == 'bottom':
        return tint(SKIN)
    if y < 2 or (y == 2 and x in (0, 7)):
        return tint(HAIR)                          # fringe
    if y in (3, 4) and x in (1, 2, 5, 6):
        return (10, 10, 14, ALPHA)                 # hollow eyes
    if y == 6 and x in (3, 4):
        return (150, 80, 70, ALPHA)                # small mouth
    return tint(SKIN)

def echo_body(face, x, y, fw, fh):
    if face == 'bottom':
        return tint(PANTS)
    if face == 'front' and y == 3:
        return tint((100, 164, 102))               # a stripe on the shirt
    return tint(SHIRT)

def echo_arm(face, x, y, fw, fh):
    if face == 'top':
        return tint(SHIRT)
    if face == 'bottom':
        return tint(SKIN)
    return tint(SHIRT if y < 3 else SKIN)

def echo_leg(face, x, y, fw, fh):
    if face == 'top':
        return tint(PANTS)
    if face == 'bottom':
        return tint(SHOE)
    return tint(PANTS if y < 5 else SHOE)

echo = blank(64, 64)
paint_box(echo, 0, 0, 8, 8, 8, echo_head)
paint_box(echo, 16, 16, 6, 8, 4, echo_body)
paint_box(echo, 40, 16, 3, 8, 3, echo_arm)
paint_box(echo, 40, 32, 3, 8, 3, echo_arm)
paint_box(echo, 0, 16, 3, 7, 3, echo_leg)
paint_box(echo, 0, 32, 3, 7, 3, echo_leg)
save_png(f'{A}/textures/entity/echo.png', echo)

# ---------------------------------------------------------------- memory heart block
save_png(f'{TB}/memory_heart.png', flesh_strip(21, (200, 48, 72), (120, 10, 60), (255, 190, 170), 1.1))
wjson(f'{TB}/memory_heart.png.mcmeta', {'animation': {'frametime': 2, 'interpolate': True}})

def cube(a, b):
    return {'from': a, 'to': b, 'faces': {f: {'texture': '#heart'} for f in ('north', 'south', 'east', 'west', 'up', 'down')}}

wjson(f'{A}/models/block/memory_heart.json', {
    'parent': 'minecraft:block/block',
    'textures': {'heart': 'usedtobe:block/memory_heart', 'particle': 'usedtobe:block/memory_heart'},
    'elements': [
        cube([2, 3, 3], [8, 11, 13]),     # left lobe
        cube([8, 3, 3], [14, 11, 13]),    # right lobe
        cube([4, 0, 4], [12, 4, 12]),     # base
        cube([6, 11, 5], [9, 15, 8]),     # aorta
        cube([10, 11, 8], [12, 14, 10]),  # vein
        cube([4, 11, 9], [6, 13, 11]),    # vein
    ]})
wjson(f'{A}/blockstates/memory_heart.json', {'variants': {'': {'model': 'usedtobe:block/memory_heart'}}})
wjson(f'{A}/models/item/memory_heart.json', {'parent': 'usedtobe:block/memory_heart'})
wjson(f'{A}/models/item/echo_spawn_egg.json', {'parent': 'minecraft:item/template_spawn_egg'})

lang = json.load(open(f'{A}/lang/en_us.json'))
lang.update({
    'block.usedtobe.memory_heart': 'Memory Heart',
    'entity.usedtobe.echo': 'Echo',
    'item.usedtobe.echo_spawn_egg': 'Echo Spawn Egg',
})
wjson(f'{A}/lang/en_us.json', lang)

# ---------------------------------------------------------------- notebooks (Book and Quills a ten year old wrote)
NOTES = {
    'first': ('my notebook #1', [
        "MY BASE!!!\nby me (age 10)\n\nthis is my secret base\nNO GIRLS NO PARENTS\n(mom can come in if she brings snacks)",
        "RULES\n1. always have torches\n2. dont dig straight down\n3. never trust a creeper\n4. write everything down so i dont forget",
        "i hid more notebooks in my other bases.\nif you find them all you will remember everything.\n\nthe compass in your pocket knows where i left them."]),
    'secret_base': ('my notebook: secret base', [
        "SECRET BASE #2 (shhh)\n\nits UNDERGROUND so nobody can find it\nthe door is a ladder\nthe password is 1234\n(dont tell dad)",
        "i put 3 diamonds in the chest for the ender dragon fight.\ni am going to beat it tomorrow.\n\nTOMORROW",
        "i never beat it.\ni dont remember why i stopped playing."]),
    'mega_house': ('my notebook: the mega house', [
        "THE MEGA HOUSE\n\n40 rooms (4 finished)\nkitchen: has furnace\nbedroom: has bed\nroom of doom: nothing yet\ndont go in the basement (theres no basement)",
        "dad says it looks like a lego that melted\nhe is WRONG\nits ART",
        "i was going to finish the other 36 rooms this summer."]),
    'treasure': ('my notebook: treasure map', [
        "TREASURE MAP!!\n\ni burried my best stuff under the X\ndig down 3 blocks\nDONT TELL ANYONE\nif you read this you are a pirate now",
        "pirate rules:\n1. dont ask where i got the diamonds\n2. no sharing\n3. (ok maybe sharing with sam)",
        "sam moved away in june.\ni still have his half of the map."]),
    'nether': ('my notebook: the nether', [
        "HOW TO GO TO THE NETHER\n\nstep 1: get obsidian\nstep 2: get flint\nstep 3: ???\nstep 4: NETHER",
        "i had 9 obsidian but you need 10. i was SO CLOSE.\ni will finish after dinner.",
        "(i didnt finish after dinner)"]),
    'trap': ('my notebook: DO NOT ENTER', [
        "DO NOT ENTER!!!\nTRAP HOUSE\n\nthere is a hole behind the door\nits 5 deep\nif you fall you LOSE",
        "the only person who ever fell in is me (twice)\n\nsam fell in once but he doesnt count he was cheating"]),
    'pen': ('my notebook: the zoo', [
        "MY ZOO\n\npets:\nbacon (pig)\nmr wool (sheep)\nchicken (just chicken)",
        "bacon fell in the hole.\ni dont want to talk about it.",
        "i miss bacon.\ni know hes not real.\ni still miss him."]),
    'graveyard': ('my notebook: RIP', [
        "RIP\n\nhere lies bacon (pig)\nhe was a good pig\nhere lies mr wool\nhere lies chicken",
        "and here lies every world i ever deleted\n\nsorry",
        "i didnt know they would stay gone."]),
    'pole': ('my notebook: the pole', [
        "THE POLE\n\ni nerd poled up here cuz it was night and i was scared\nit was only a zombie\nbut it was a BIG zombie",
        "from up here you can see all my bases\nthey look small\nthey looked so big when i was building them"]),
    'castle': ('my notebook: the castle', [
        "MY CASTLE\n\nKING: me\nQUEEN: nobody yet\nKNIGHTS: 1 wolf (he doesnt listen)",
        "DECREES\n1. everyone must be nice to me\n2. this will be the biggest castle EVER MADE",
        "its only 13 blocks wide.\ni thought it went on forever."]),
}
CORRUPT = {
    'corrupt_1': ('something wrote this', [
        "you found me.\nit was easier when you were small.\n\nthe red things are hearts. theyre what i couldnt let go of.",
        "touch them.\nit hurts them and it hurts me.\nbut its the only way out."]),
    'corrupt_2': ('something wrote this', [
        "something grew in here after you left.\nit eats the parts you stopped looking at.\n\ndont let it near you.",
        "(if you look right at it, it stops. i checked.)"]),
    'corrupt_3': ('something wrote this', [
        "one more.\nthen you can go.\n\ni dont want you to go.\ni never did.\ni know you have to."]),
}

def snbt(s):
    return '"' + s.replace('\\', '\\\\').replace('"', '\\"') + '"'

def book_entry(title, pages, memory_id=None):
    parts = []
    if memory_id:
        parts.append('usedtobe_memory:%s' % snbt(memory_id))
    parts.append('pages:[%s]' % ','.join(snbt(p) for p in pages))
    return {'type': 'minecraft:item', 'name': 'minecraft:writable_book', 'weight': 1, 'functions': [
        {'function': 'minecraft:set_nbt', 'tag': '{%s}' % ','.join(parts)},
        {'function': 'minecraft:set_name', 'name': {'text': title, 'italic': False}}]}

def chest_table(book, filler, extra=None):
    pools = [
        {'rolls': 1, 'entries': [book]},
        {'rolls': {'type': 'minecraft:uniform', 'min': 1, 'max': 3}, 'entries': filler},
    ]
    if extra:
        pools.append({'rolls': 1, 'entries': extra})
    return {'type': 'minecraft:chest', 'pools': pools}

FILLER = [item('minecraft:bread', 6, 1, 3), item('minecraft:apple', 4, 1, 3), item('minecraft:torch', 8, 4, 12),
          item('minecraft:coal', 5, 2, 6), item('minecraft:cobblestone', 6, 8, 24), item('minecraft:wooden_sword', 2)]

for nid, (title, pages) in NOTES.items():
    extra = None
    if nid in ('secret_base', 'treasure'):
        extra = [item('minecraft:diamond', 1, 1, 3)]
    wjson(f'{D}/loot_tables/chests/book_{nid}.json', chest_table(book_entry(title, pages, nid), FILLER, extra))

for cid, (title, pages) in CORRUPT.items():
    wjson(f'{D}/loot_tables/chests/book_{cid}.json',
          chest_table(book_entry(title, pages), [item('minecraft:rotten_flesh', 5, 1, 4), item('minecraft:bone', 3, 1, 2)]))

print('v2 assets ok')
